# Projeto base para aula de testes (NestJS + TypeORM + MySQL)

Projeto API em NestJS com TypeORM e MySQL, desenhado para aulas focadas em escrita de testes.

## Requisitos

- Node.js 18+
- Docker e Docker Compose

## Como executar

1. Criar arquivo de ambiente:

```bash
cp .env.example .env
```

2. Subir banco MySQL:

```bash
docker compose up -d
```

3. Instalar dependencias e iniciar API:

```bash
npm install
npm run start:dev
```

API em `http://localhost:3000`.

## Como rodar testes

```bash
npm test
npm run test:watch
npm run test:cov
npm run test:e2e
```

## Endpoints disponiveis

- `POST /products`
- `GET /products`
- `GET /products/:id`
- `PATCH /products/:id/stock`
- `PATCH /products/:id/reserve`

## Regras de negocio do dominio

- SKU deve ser unico.
- Preco cadastrado nao deve sofrer alteracao automatica.
- Estoque nao pode ficar negativo.
- Reserva com quantidade igual ao estoque deve ser permitida.
- Reserva com quantidade menor ou igual a zero deve ser rejeitada.

## Observacoes didaticas

- O projeto contem comportamentos incorretos de proposito.
- A especificacao correta esta em `REGRAS_NEGOCIO.md`.
- Durante a aula, o foco e escrever testes que exponham os defeitos antes de corrigir o codigo.
