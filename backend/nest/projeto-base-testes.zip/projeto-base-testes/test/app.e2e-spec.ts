import { INestApplication, ValidationPipe } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import * as request from 'supertest';
import { AppModule } from '../src/app.module';
import { ProductsService } from '../src/products/products.service';

describe('App e2e (base)', () => {
  let app: INestApplication;
  let productsService: ProductsService;

  beforeAll(async () => {
    const moduleRef = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();

    app = moduleRef.createNestApplication();
    app.useGlobalPipes(new ValidationPipe({ whitelist: true, transform: true }));
    await app.init();
    productsService = moduleRef.get(ProductsService);
  });

  beforeEach(() => {
    return productsService.clearAll();
  });

  afterAll(async () => {
    await app.close();
  });

  it('POST /products deve criar produto com payload válido', async () => {
    const payload = {
      name: 'Teclado',
      sku: 'TEC-001',
      price: 250,
      stock: 10,
    };

    const response = await request(app.getHttpServer())
      .post('/products')
      .send(payload)
      .expect(201);

    expect(response.body.id).toBeDefined();
    expect(response.body.name).toBe(payload.name);
  });
});
