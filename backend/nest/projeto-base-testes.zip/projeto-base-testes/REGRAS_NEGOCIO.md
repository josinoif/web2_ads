# Regras de negocio esperadas

Este documento define o comportamento correto esperado do sistema.  
Algumas implementacoes atuais violam estas regras de forma intencional para fins didaticos.

## Contexto tecnico

- API NestJS
- Persistencia com TypeORM
- Banco MySQL

## Regras principais

1. SKU deve ser unico por produto.
2. Nao deve existir alteracao automatica de preco no cadastro.
3. Estoque nunca pode ficar negativo.
4. A reserva de estoque deve permitir reservar exatamente o total disponivel.
5. Reservas com quantidade zero ou negativa devem ser rejeitadas.

## Objetivo da aula

Os alunos devem escrever testes que revelem divergencias entre esta especificacao e o comportamento implementado.
