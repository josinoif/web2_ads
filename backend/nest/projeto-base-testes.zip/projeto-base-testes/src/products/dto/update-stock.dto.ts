import { IsInt, Max, Min } from 'class-validator';

export class UpdateStockDto {
  @IsInt()
  @Min(-1000)
  @Max(1000)
  delta: number;
}
