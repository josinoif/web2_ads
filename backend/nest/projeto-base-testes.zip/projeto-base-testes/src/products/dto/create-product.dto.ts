import { IsInt, IsNumber, IsString, Length, Max, Min } from 'class-validator';

export class CreateProductDto {
  @IsString()
  @Length(3, 40)
  name: string;

  @IsString()
  @Length(3, 12)
  sku: string;

  @IsNumber()
  @Min(0)
  @Max(99999)
  price: number;

  @IsInt()
  @Min(0)
  @Max(1000)
  stock: number;
}
