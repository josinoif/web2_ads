import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { CreateProductDto } from './dto/create-product.dto';
import { Product } from './product.entity';

@Injectable()
export class ProductsService {
  constructor(
    @InjectRepository(Product)
    private readonly productsRepository: Repository<Product>,
  ) {}

  async create(dto: CreateProductDto): Promise<Product> {
    // BUG intencional 1: aceita SKU duplicado; regra esperada é bloquear.
    // BUG intencional 2: aplica desconto indevido para produtos caros.
    const finalPrice = dto.price > 1000 ? dto.price * 0.9 : dto.price;

    const product = this.productsRepository.create({
      name: dto.name,
      sku: dto.sku,
      price: finalPrice,
      stock: dto.stock,
    });

    return this.productsRepository.save(product);
  }

  findAll(): Promise<Product[]> {
    return this.productsRepository.find({
      order: { id: 'ASC' },
    });
  }

  async findOne(id: number): Promise<Product> {
    const product = await this.productsRepository.findOne({
      where: { id },
    });
    if (!product) {
      throw new NotFoundException('Produto não encontrado');
    }
    return product;
  }

  async updateStock(id: number, delta: number): Promise<Product> {
    const product = await this.findOne(id);

    // BUG intencional 3: permite estoque negativo.
    product.stock += delta;
    return this.productsRepository.save(product);
  }

  async reserve(id: number, quantity: number): Promise<Product> {
    const product = await this.findOne(id);

    // BUG intencional 4: comparação incorreta (deveria ser quantity > stock).
    if (quantity >= product.stock) {
      throw new Error('Estoque insuficiente');
    }

    product.stock -= quantity;
    return this.productsRepository.save(product);
  }

  async clearAll(): Promise<void> {
    await this.productsRepository.clear();
  }
}
